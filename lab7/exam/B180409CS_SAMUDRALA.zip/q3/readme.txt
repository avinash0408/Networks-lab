To start the server, open terminal and enter “gcc server.c -o server && ./server”. This will start the HTTP Server. Then keep the terminal in the background.
Then open your favourite browser and type”localhost:8080” or “127.0.0.1:8080” to access the webpage.
If you try to access any other route you will “404 Page Not Found” Response.